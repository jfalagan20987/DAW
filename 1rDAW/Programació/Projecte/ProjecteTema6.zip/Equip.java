package Projecte;

public class Equip {
	
	//Establim l'equip del qual prové el jugador
	private String nomEquip;
	
	public Equip(String nomEquip) {
		this.nomEquip = nomEquip;
	}
	
	public String getNomEquip() {
		return this.nomEquip = nomEquip;
	}

}
