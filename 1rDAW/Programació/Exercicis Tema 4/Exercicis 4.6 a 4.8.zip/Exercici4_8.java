package NewPackage;

import java.util.Scanner;

public class Exercici4_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
	
		System.out.println("Introdueix el nombre de la taula de multiplicar:");
		int taula = sc.nextInt();
		int x = 10;
		
		while (x >= 1) {
			System.out.println(x * taula);
			x = x - 1;
		}
	}

}
