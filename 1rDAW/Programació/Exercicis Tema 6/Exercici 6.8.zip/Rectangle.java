package Figures;

public class Rectangle extends Figura{
	@Override
	void dibuixar() {
		System.out.println("Dibuixant rectangle");
	}
}