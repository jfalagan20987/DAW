package Figures;

public class Cercle extends Figura{
	@Override
	void dibuixar() {
		System.out.println("Dibuixant cercle");
	}
}
