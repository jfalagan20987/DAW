package Figures;

public abstract class Figura {
	void dibuixar() {
		System.out.println("Dibuixar");
	}
}

