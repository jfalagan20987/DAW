package UD9Ex2;

public class Persona {
	
	protected String nom;
	protected String dni;
	protected int edat;
	
	public Persona(String nom, String dni, int edat) {
		this.nom = nom;
		this.dni = dni;
		this.edat = edat;
	}

}
