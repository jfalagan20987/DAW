package UD9Ex13;

public class Llibre {

	private String nom;
	
	public Llibre(String nom) {
		this.nom = nom;
	}
	
	public String getNom() {
		return this.nom = nom;
	}
	
	public String toString() {
		String dadesLlibre = "";
		dadesLlibre = dadesLlibre +nom;
		return dadesLlibre;
	}

}
