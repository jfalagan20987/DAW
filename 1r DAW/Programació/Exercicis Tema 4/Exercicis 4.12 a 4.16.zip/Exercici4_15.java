package NewPackage;

public class Exercici4_15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int files = 5;
		
		for (int i = 0 ; i <=files ; i++) {
			for (int j = 0 ; j <=i ; j++) {
				System.out.print("a ");
			}
			System.out.println();
		}

	}

}
