package NewPackage;

import java.util.Scanner;

public class Exercici4_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		int taula = sc.nextInt();
		
		for (int i = 0 ; i <= 30 ; i = i + 3) {
			System.out.println(i+ " x " +taula+ " = " +i*taula);
		}
		
		sc.close();

	}

}
