package NewPackage;

import java.util.Scanner;

public class Exercici4_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introdueix el nombre de files que tindrà la piràmide:");
		int files = sc.nextInt();
		
		for (int i = 1 ; i <= files ; i++) {
			for (int espai = 1 ; espai <=files-i ; espai++) {
				System.out.print(" ");
			}
			for (int j = 1 ; j <= (i*2)-1 ; j++) {
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
